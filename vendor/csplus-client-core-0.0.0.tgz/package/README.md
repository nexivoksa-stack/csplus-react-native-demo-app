# @csplus/client-core

Framework-agnostic browser SDK for starting a voice call with a CS+ agent.
Works with plain `<script>` tags, Vue, Angular, Svelte, or hand-rolled code.
Using React? Use [`@csplus/client-react`](../client-react) instead.

```ts
import { Client } from "@csplus/client-core";

const client = new Client({ publicKey: "csp_pk_live_..." });

// Call this from a click or tap: browsers refuse to start audio otherwise.
const call = await client.startCall();

call.on("message", (msg) => console.log(msg.role, msg.text));
call.on("ended", (reason) => console.log("ended:", reason)); // user | agent | timeout
call.on("error", (err) => console.error(err.code, err.message));

await call.end();
```

Or from a `<script>` tag, which exposes one global, `CSPlus`:

```html
<script src="https://cdn.jsdelivr.net/npm/@csplus/client-core@0/dist/csplus.min.js"></script>
<script>
  const client = new CSPlus.Client({ publicKey: "csp_pk_live_..." });
</script>
```

## What you get

- `client.startCall()` resolves once connected and throws a `CallError` on
  failure. One live call per `Client`.
- `call.state`, `call.agentState`, `call.messages`, `call.isMuted`, and events
  for each of them, plus `audioLevel` for visualizers.
- `mute()`, `unmute()`, `setMicrophone(id)`, `sendText(text)`, `resumeAudio()`,
  `end()`, and `client.listMicrophones()`.
- Every failure is a `CallError` with a stable `code` and a `retriable` flag.
  You never need to catch a LiveKit or DOM error type.

## Compatibility

- `livekit-client` is pinned to an **exact** version inside this package and is
  a regular dependency, not a peer. You never install or import it yourself.
  The version is in this package's `package.json`; upgrading it is always its
  own release.
- Requires a browser with WebRTC and `getUserMedia`. Calls must start from a
  user gesture.

See the [repository](https://github.com/nexivoksa-stack/csplus-client-sdk) for
the full API and design notes.
