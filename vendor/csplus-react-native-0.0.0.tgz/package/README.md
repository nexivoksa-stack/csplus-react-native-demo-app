# @csplus/react-native

`useCall` for iOS and Android: start a voice call with a CS+ agent from a React
Native or Expo app. It is the same hook as
[`@csplus/client-react`](../client-react), with the phone's audio, permissions
and app lifecycle plugged in.

> **Status: pre-release (0.x).** Built against the plan in
> [`CSPLUS_REACT_NATIVE_SDK_PLAN.md`](../../CSPLUS_REACT_NATIVE_SDK_PLAN.md).
> The JavaScript is unit-tested; **nothing here has yet been run on a physical
> device**. That is Phase 0/5 of the plan, in `csplus-react-native-demo-app`.

## Install

Needs a **development build**. Expo Go cannot load the native WebRTC modules.

```bash
npm install @csplus/react-native @livekit/react-native \
  @livekit/react-native-webrtc livekit-client@~2.22.3
```

### Expo

```bash
npx expo install @csplus/react-native @livekit/react-native \
  @livekit/react-native-webrtc @livekit/react-native-expo-plugin \
  livekit-client@~2.22.3 expo-dev-client
```

```jsonc
// app.json
{ "expo": { "plugins": [
  "expo-dev-client",
  ["@csplus/react-native", {
    "microphonePermission": "$(PRODUCT_NAME) uses the microphone so you can talk to our assistant."
  }]
] } }
```

Then `npx expo prebuild` and build a development client. The plugin replaces
listing `@livekit/react-native-expo-plugin` and
`@config-plugins/react-native-webrtc` yourself (list only ours). It does:

| | |
|---|---|
| iOS | writes `NSMicrophoneUsageDescription` from `microphonePermission` (**required**, unless your app config already has one: App Review rejects a vague reason, so there is no default); adds the `audio` background mode |
| Android | `INTERNET`, `ACCESS_NETWORK_STATE`, `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`, the foreground-service permissions, and the Bluetooth permissions. **Not** `CAMERA`, `SYSTEM_ALERT_WINDOW` or `WAKE_LOCK`, which `@config-plugins/react-native-webrtc` adds and a voice call does not need |
| both | LiveKit's plugin, which calls LiveKit's native `setup` for you (no `MainApplication`/`AppDelegate` edits) and adds the Podfile source its WebRTC pod needs; Android is set to voice-call audio |

Options: `microphonePermission` (string), `background` (default `true`; `false`
drops the `audio` mode and the foreground-service permissions, for calls that
should end when the app is backgrounded), `bluetooth` (default `true`).
Google Play asks for a declaration for the foreground-service permissions, and
the service that keeps a call alive on Android 14+ is **yours** to start; use
`background: false` if you do not want either. The plugin is idempotent, so
`npx expo prebuild` without `--clean` is safe.

### Bare React Native

The same changes by hand (a JS package cannot edit your native files):

- **Android** `MainApplication`, first thing in `onCreate()`:
  `LiveKitReactNative.setup(this, AudioType.CommunicationAudioType())`
  (`import com.livekit.reactnative.LiveKitReactNative` and `...audio.AudioType`).
  `AndroidManifest.xml`: the Android permissions in the table above.
- **iOS** `AppDelegate`, first thing in `didFinishLaunchingWithOptions`:
  `[LivekitReactNative setup];` (`#import "LivekitReactNative.h"`), Swift:
  `LivekitReactNative.setup()`. `Info.plist`: `NSMicrophoneUsageDescription`, and
  `UIBackgroundModes` containing `audio`. `Podfile`: add both sources above the
  first line, `source 'https://github.com/livekit/podspecs.git'` then
  `source 'https://cdn.cocoapods.org/'`, then `pod install`.

If `npm install` stops with an `ERESOLVE` error about `react-dom`, install it at
your React version first (`npx expo install react-dom`): LiveKit's React
Native package pulls a component library that peers on it, and npm otherwise
picks a newer `react-dom` than your React.

`livekit-client` must be installed **once**, at the version above: two copies in
one app double its size and split its state. `setup()` warns if the version is
not the one this release was built against.

## Use

```tsx
// index.js -- once, before anything else
import { setup } from "@csplus/react-native";
setup();
```

```tsx
import { useCall } from "@csplus/react-native";

function Talk() {
  const { state, agentState, messages, error, start, end, mute, unmute, isMuted } =
    useCall({ publicKey: "csp_pk_live_...", appId: "com.acme.app" });

  return (
    <>
      <Button title="Talk to us" onPress={() => start().catch(() => {})} />
      <Button title="Hang up" onPress={end} />
      <Text>{state} / {agentState}</Text>
      {error && <Text>{error.code}</Text>}
    </>
  );
}
```

Everything on the web hook works the same (`state`, `agentState`, `messages`,
`isMuted`, `error`, `endReason`, `start`, `end`, `mute`, `unmute`, `sendText`,
`setMicrophone`, `listMicrophones`, `onEnded`, `onAudioLevel`). What is
different on a phone:

- **`setup()`** installs the native WebRTC layer. Call it once at app entry.
- **`appId`** is your bundle id / application id, for keys restricted to
  specific apps. It is declared by the app, not proven by it.
- **Signed mode.** Pass `callGrant` (a function that asks *your backend* for a
  fresh single-use grant) instead of `publicKey`, so the app never holds a
  long-lived credential. See `callGrant` in the options table.
- **Audio output.** `availableAudioOutputs`, `audioOutput` and
  `setAudioOutput(...)`; `showAudioRoutePicker()` on iOS. iOS only lets an app
  pick the speaker or the OS's choice (`"speaker"`, `"default"`).
- **`background`**: `"continue"` (default) keeps the call alive when the app is
  backgrounded, which needs the iOS `audio` background mode and, on Android 14+,
  a foreground service of type `microphone`; `"end"` hangs up instead.
- `resumeAudio()` exists for parity and does nothing: there is no autoplay
  policy on a phone, and `audio_blocked` is never raised.
- `onInputLevel` does not fire on a phone in this release.

Two error codes are specific to this package's world: `audio_session_failed`
(the phone could not set up audio) and, with a `callGrant`, `invalid_grant` /
`grant_unavailable`.
