// The Expo CLI looks for this file in a package's root. It only re-exports the
// compiled plugin (built from plugin/src by `pnpm build`).
module.exports = require("./plugin/build");
