# @csplus/client-react

React hook for starting a voice call with a CS+ agent. A thin wrapper over
[`@csplus/client-core`](../client-core); supports React 18 and 19.

```tsx
import { useCall } from "@csplus/client-react";

function Talk() {
  const { state, agentState, messages, error, start, end, mute, unmute, isMuted } =
    useCall({ publicKey: "csp_pk_live_..." });

  return (
    <>
      {/* start() must run from a click: browsers refuse to start audio otherwise. */}
      <button onClick={() => start().catch(() => {})} disabled={state === "connecting"}>
        Start call
      </button>
      <button onClick={end}>Hang up</button>
      <button onClick={isMuted ? unmute : mute}>{isMuted ? "Unmute" : "Mute"}</button>
      <p>{state} / {agentState}</p>
      {error && <p role="alert">{error.code}: {error.message}</p>}
      {messages.map((m) => <p key={m.id}>{m.role}: {m.text}</p>)}
    </>
  );
}
```

- `state` is `"idle"` before the first `start()` and `"connecting"` while it is
  pending; after that it is the core's `CallState`.
- `start()` rejects with a `CallError` **and** sets `error`.
- `endReason` (`user | agent | timeout`) and an `onEnded(reason)` option tell
  you why a call ended. Neither fires for a failure.
- The agent's output level never re-renders: pass `onAudioLevel`, or read the
  ref from `useAudioLevel(call)` in your own animation loop.
- Leaving the component ends a live call.

Everything from `@csplus/client-core` that you need (`CallError`, and the
types) is re-exported, so one import covers it.
